<?php 
session_start();
if (isset($_SESSION['ID']) && isset($_SESSION['NAME'])) {

?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Seafarer International</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/prostyle1.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>

    <link rel="apple-touch-icon" href="https://i.pinimg.com/564x/3b/85/68/3b85687de2d7c83b66e7b8137b598ab6.jpg">
    <link rel="shortcut icon" href="https://i.pinimg.com/564x/3b/85/68/3b85687de2d7c83b66e7b8137b598ab6.jpg">

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
        <!-- sidebar menu area start -->
        <div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <a href="index.html"><img src="assets/images/Seafarer.png" class="rounded-circle" alt="logo"></a>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu" id="menu">
                            <li><a href="admin.php"><i class="ti-dashboard"></i> <span>dashboard</span></a></li>
                            <li><a href="admin-ship.php"><i class="fa fa-ship" aria-hidden="true"></i> <span>Manage Ships</span></a></li>
                            <li><a href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i> <span> Logout</span></a></li>
                            
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            <div class="header-area">
                <div class="row align-items-center">
                    <!-- nav and search button -->
                    <div class="col-md-6 col-sm-8 clearfix">
                        <div class="nav-btn pull-left">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="search-box pull-left">
                            
                        </div>
                    </div>
                    
                </div>
            </div>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left">Dashboard</h4>
                            <ul class="breadcrumbs pull-left">
                                <li><a href="index.html">Home</a></li>
                                <li><span>Dashboard</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 clearfix">
                        <div class="user-profile pull-right">
                            <img class="avatar user-thumb" src="assets/images/adminph.png" alt="avatar">
                            <h4 class="user-name dropdown-toggle" data-toggle="dropdown">Admin</h4>
                        </div>
                    </div>
                </div>
            </div>
            <!-- page title area end -->
            
            <div class="container-fluid">
                <?php if (isset($_GET['success'])) { ?>
                    <div class="myDiv">
                        <div class="row">
                            <div class="col mt-5">
                                <div class="card bg-success">
                                    <h4 class="text-center text-light"><?php echo $_GET['success']; ?></h4>
                                </div> 
                            </div>
                        </div>
                    </div> 
                <?php } ?>
                <div class="row">
                    <div class="col">
                        <h4 class="text-center mt-4 mb-5">Add Crew</h4>    
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <a href="admin-crew.php" class="btn btn-danger mb-5 ml-3"><i class="fa fa-angle-left" aria-hidden="true"></i> Back</a>
                    </div>
                </div>
                <div class="row">
                        <div class="col">
                            <form action="code.php" method="POST">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col form-group">
                                        <label>Full Name</label>
                                        <input type="text" name="fname" class="form-control" required="">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col form-group">
                                        <label>Age</label>
                                        <input type="text" name="age" class="form-control" required="">
                                    </div>
                                    <div class="col form-group">
                                       <label>Height</label>
                                       <input type="text" name="heigh" class="form-control"> 
                                    </div>
                                    <div class="col form-group">
                                       <label>Weight</label>
                                       <input type="text" name="weight" class="form-control"> 
                                    </div>
                                </div>
                                <div class="row">  
                                    <div class="col form-group">
                                        <label>Rank</label>
                                        <select name="rank" class="form-control" required="">
                                            <option>Choose...</option>
                                            <option>Master/Captain</option>
                                            <option>Chief Mate</option>
                                            <option>Second Mate</option>
                                            <option>Third Mate</option>
                                            <option>Deck Cadet</option>
                                            <option>Cheif Engineer</option>
                                            <option>Second Engineer</option>
                                            <option>Third Engineer</option>
                                            <option>Fourth Engineer</option>
                                            <option>Engineer Cadet</option>
                                            <option>Electrician</option>
                                            <option>Boatswain</option>
                                            <option>Pump Man</option>
                                            <option>Able-Bodied Seaman</option>
                                            <option>Ordinary Seaman</option>
                                            <option>fitter</option>
                                            <option>Oiler</option>
                                            <option>Wiper</option>
                                            <option>Chief cook</option>
                                            <option>Steward</option>
                                        </select>
                                    </div> 
                                </div>
                            </div>
                        </div>
                </div>
                <div class="row">
                    <div class="col form-group">
                        <button type="submit" class="form-control btn btn-primary mt-5" name="crew_btn">Submit</button>
                    </div>    
                </div>  
                </form>  
            </div>
        </div>
        <!-- main content area end -->
        <!-- footer area start-->
        <footer>
            <div class="footer-area">
                <p>© Copyright 2018. All right reserved.</p>
            </div>
        </footer>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->
    
    <!-- offset area end -->
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    <script src="assets/js/prostyle1.js"></script>

    <!-- start chart js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
    <!-- start highcharts js -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <!-- start zingchart js -->
    <script src="https://cdn.zingchart.com/zingchart.min.js"></script>
    <script>
    zingchart.MODULESDIR = "https://cdn.zingchart.com/modules/";
    ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "ee6b7db5b51705a13dc2339db3edaf6d"];
    </script>
    <!-- all line chart activation -->
    <script src="assets/js/line-chart.js"></script>
    <!-- all bar chart activation -->
    <script src="assets/js/bar-chart.js"></script>
    <!-- all pie chart -->
    <script src="assets/js/pie-chart.js"></script>
    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>


    <script>
             $( ".myDiv" ).show( "slow").delay(3500).fadeOut('slow', function() {
          $(this).remove();
     }); 
    </script>
</body>



</html>


<?php 
}else{
    header("Location:admin.php");
    exit();
}
 ?>
