<?php

session_start();
$sname = "localhost";
$uname = "root";
$password = "";

$db_name = "olfu_one";

$conn = mysqli_connect($sname, $uname, $password, $db_name);

#adminlogin
if (isset($_POST['username']) && isset($_POST['password'])) {

	$user = $_POST['username'];
	$pass = $_POST['password'];

	if ($user == 'admin' && $pass = 'admin') {

		$_SESSION['USERNAME'] = 'admin';
		$_SESSION['NAME'] = 'admin';
		$_SESSION['ID'] = '999';
		header("location: admin.php?success=Successful Login!");
		exit();
	} 
	
	function validate($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	$uname = validate($_POST['username']);
	$pass = validate($_POST['password']);
	if (empty($uname)) {
		header("location: index.php?error=Username is required");
		exit();
	}elseif (empty($pass)) {
		header("location: index.php?error=Password is required");
		exit();
	}else{

		$pass = md5($pass);
		$sql = "SELECT * FROM admin WHERE USERNAME = '$uname' AND PASSWORD = '$pass'";

		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) ==1) {
			$row = mysqli_fetch_assoc($result);

			if ($row['USERNAME']== $uname && $row['PASSWORD'] == $pass) {
				$_SESSION['USERNAME'] = $row['USERNAME'];
				$_SESSION['NAME'] = $row['NAME'];
				$_SESSION['ID'] = $row['ID'];
				header("Location:admin.php");
				exit();
			}else{
				header("Location:Admin-login.php?error=Incorrect username or password");
				exit();
			}
		}else{
			header("Location:Admin-login.php?error=Incorrect username or password");
			exit();
		}
	}
}

if (isset($_POST['crew_btn'])) {
    // for the database
    
    $fname = stripslashes($_POST['fname']);
    $age = stripslashes($_POST['age']);
    $heigh = stripslashes($_POST['heigh']);
    $weight = stripslashes($_POST['weight']);
    $rank = stripslashes($_POST['rank']);


        $sql = "INSERT INTO tbl_crew SET fullname='$fname', age='$age',height='$heigh',weight='$weight',rank='$weight'";

        #
        if(mysqli_query($conn, $sql)){
          header("Location: admin-addcrew.php?success=Data has added successfully!");
        } else {
          echo '<script> alert("Failed to delete1"); </script>';
        }
    
  }

if (isset($_POST['btn_addcrew'])) {
	$shipid = stripslashes($_POST['addcrew']);
	$shipname = stripslashes($_POST['shipname']);


	$_SESSION['shipid'] = $shipid;
	$_SESSION['shipname'] = $shipname;
	header("Location: admin-crew.php");
}

if (isset($_POST['ship_btn'])) {
    // for the database
    
    $name = stripslashes($_POST['name']);
    $status = stripslashes($_POST['status']);
    $speed = stripslashes($_POST['speed']);
    $year = stripslashes($_POST['yr']);
    $profileImageName = time() . '-' . $_FILES["profile_image"]["name"];


    // For image upload
    $target_dir = "images/";
    $target_file = $target_dir . basename($profileImageName);
    // VALIDATION
    // validate image size. Size is calculated in Bytes
    if($_FILES['profile_image']['size'] > 200000) {
      $msg = "Image size should not be greated than 200Kb";
      $msg_class = "alert-danger";
    }
    


	
    // check if file exists
    if(file_exists($target_file)) {
      header("Location: admin-addship.php?error=This photo is already Exist&$user_data");
    }
    // Upload image only if no errors
    if (empty($error)) {
      if(move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file)) {
      	
        $sql = "INSERT INTO tbl_ship SET profile_image='$profileImageName', name='$name', status='$status',speed='$speed',year='$year'";

        #
        if(mysqli_query($conn, $sql)){
          header("Location: admin-addship.php?success=Data has added successfully!");
        } else {
          echo '<script> alert("Failed to delete1"); </script>';
        }
      } else {
        echo '<script> alert("Failed to delete2"); </script>';
      }
    }
  }


?>