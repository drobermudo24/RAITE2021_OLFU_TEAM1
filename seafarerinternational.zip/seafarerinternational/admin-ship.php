<?php 
session_start();
if (isset($_SESSION['ID']) && isset($_SESSION['NAME'])) {

?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Seafarer International</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/prostyle1.css">

    <!-- Start datatable css -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>

    <link rel="apple-touch-icon" href="https://i.pinimg.com/564x/3b/85/68/3b85687de2d7c83b66e7b8137b598ab6.jpg">
    <link rel="shortcut icon" href="https://i.pinimg.com/564x/3b/85/68/3b85687de2d7c83b66e7b8137b598ab6.jpg">

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
        <!-- sidebar menu area start -->
        <div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <a href="index.html"><img src="assets/images/Seafarer.png" class="rounded-circle" alt="logo"></a>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu" id="menu">
                            <li><a href="admin.php"><i class="ti-dashboard"></i> <span>dashboard</span></a></li>
                            <li><a href="admin-ship.php"><i class="fa fa-ship" aria-hidden="true"></i> <span>Manage Ships</span></a></li>
                            <li><a href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i> <span> Logout</span></a></li>
                            
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            <div class="header-area">
                <div class="row align-items-center">
                    <!-- nav and search button -->
                    <div class="col-md-6 col-sm-8 clearfix">
                        <div class="nav-btn pull-left">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="search-box pull-left">
                            
                        </div>
                    </div>
                    
                </div>
            </div>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left">Dashboard</h4>
                            <ul class="breadcrumbs pull-left">
                                <li><a href="index.html">Home</a></li>
                                <li><span>Dashboard</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 clearfix">
                        <div class="user-profile pull-right">
                            <img class="avatar user-thumb" src="assets/images/adminph.png" alt="avatar">
                            <h4 class="user-name dropdown-toggle" data-toggle="dropdown">Admin</h4>
                        </div>
                    </div>
                </div>
            </div>
            <!-- page title area end -->
            
            <div class="container-fluid">
                <div class="row">
                    <div class="col mt-5">
                        <h4 class="text-center font-weight-bold">Manage Ship</h4>
                    </div>
                </div>
                <div class="row ">
                        <div class="col mt-5">
                            <div class="card ">
                                <div class="card-body">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col mb-4">
                                                <a href="admin-addship.php" class="btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i> Add Ship</a>    
                                            </div>
                                            <div class="col">
                                                <h2 class="header-title text-center">List of Ship</h2>    
                                            </div>
                                            <div class="col">
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                                        <thead class="bg-my-secondary ">
                                            <tr>
                                                <th class="text-center">No.</th>
                                                <th class="text-center">Ship</th>
                                                <th class="text-center">Name</th>
                                                <th class="text-center">Status.</th>
                                                <th class="text-center">Speed</th>
                                                <th class="text-center">Year</th>
                                                <th class="text-center">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $sname = "localhost";
                                                $uname = "root";
                                                $password = "";
                                                $db_name = "olfu_one";

                                                $conn = mysqli_connect($sname, $uname, $password, $db_name);

                                                $table = mysqli_query($conn,'SELECT * FROM tbl_ship');

                                                if(mysqli_num_rows($table) > 0)
                                                { 
                                                
                                                  while ($row = mysqli_fetch_assoc($table)) 
                                                  {  
                                                        
                                                  ?>
                                            <tr>
                                                <td class="text-center"><?php echo $row["id"]; ?></td>
                                                <td class="text-center"><img src="<?php echo 'images/' . $row['profile_image'] ?>" width="90" height="90" alt=""></td>
                                                <td class="text-center"><a href="" class="text-dark"><?php echo $row["name"]; ?></a></td>
                                                <td class="text-center"><a href="" class="text-dark"><?php echo $row["status"]; ?></a></td>

                                                <td class="text-center"><a href="" class="text-dark"><?php echo $row["speed"]; ?></a></td>

                                                <td class="text-center"><a href="" class="text-dark"><?php echo $row["year"]; ?></a></td>
                                                <td>
                                                    <ul class="d-flex justify-content-center">
                                                        <form action="code.php" method="POST">
                                                            <input type="hidden" name="addcrew" value="<?php echo $row["id"]; ?>">
                                                            <input type="hidden" name="shipname" value="<?php echo $row["name"]; ?>">
                                                            <button class="mr-3 border-0 text-success" name="btn_addcrew" type="submit"> Add Crew <i class="fa fa-arrow-right" aria-hidden="true"></i></button>
                                                        </form>
                                                    </ul>
                                                </td>
                                            </tr>
                                                <?php
                                                    }
                                                        
                                                    }

                                                    ?> 
                                        </tbody>
                                    </table>   
                                </div>
                            </div>
                        </div>
                    </div>  
            </div>
        </div>
        <!-- main content area end -->
        <!-- footer area start-->
        <footer>
            <div class="footer-area">
                <p>© Copyright 2018. All right reserved.</p>
            </div>
        </footer>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->
    
    <!-- offset area end -->
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    <script src="assets/js/prostyle1.js"></script>

    <!-- start chart js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
    <!-- start highcharts js -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <!-- start zingchart js -->
    <script src="https://cdn.zingchart.com/zingchart.min.js"></script>
    <script>
    zingchart.MODULESDIR = "https://cdn.zingchart.com/modules/";
    ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "ee6b7db5b51705a13dc2339db3edaf6d"];
    </script>
    <!-- all line chart activation -->
    <script src="assets/js/line-chart.js"></script>
    <!-- all bar chart activation -->
    <script src="assets/js/bar-chart.js"></script>
    <!-- all pie chart -->
    <script src="assets/js/pie-chart.js"></script>
    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>

    <!-- Start datatable js -->
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>


    <script>
             $( ".myDiv" ).show( "slow").delay(3500).fadeOut('slow', function() {
          $(this).remove();
     }); 
    </script>
</body>



</html>


<?php 
}else{
    header("Location:admin.php");
    exit();
}
 ?>
